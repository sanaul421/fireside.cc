/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { BrowserRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence, useMotionValue, useTransform, animate, useInView } from 'motion/react';
import { 
  Play, 
  Users, 
  Zap, 
  TrendingUp, 
  Globe, 
  CheckCircle2, 
  ArrowRight, 
  Menu, 
  X,
  Mic2,
  Share2,
  Target,
  Linkedin,
  Youtube,
  Twitter,
  Award,
  ShieldCheck,
  MessageSquare,
  BarChart3
} from 'lucide-react';

// --- Shared Components ---

const NoiseOverlay = () => (
  <div className="fixed inset-0 pointer-events-none z-[100] opacity-[0.03] mix-blend-overlay">
    <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <filter id="noiseFilter">
        <feTurbulence type="fractalNoise" baseFrequency="0.65" numOctaves="3" stitchTiles="stitch" />
      </filter>
      <rect width="100%" height="100%" filter="url(#noiseFilter)" />
    </svg>
  </div>
);

const RocketLogo = ({ className = "w-8 h-8" }: { className?: string }) => (
  <div className={`${className} relative flex items-center justify-center`}>
    <svg viewBox="0 0 100 100" className="w-full h-full fill-current transform rotate-45">
      {/* Rocket Body */}
      <path d="M50 10C50 10 30 40 30 70C30 85 40 90 50 90C60 90 70 85 70 70C70 40 50 10 50 10Z" />
      {/* Left Fin */}
      <path d="M30 60L15 85L30 80V60Z" />
      {/* Right Fin */}
      <path d="M70 60L85 85L70 80V60Z" />
      {/* Window */}
      <circle cx="50" cy="50" r="8" className="fill-white/20" />
      {/* Exhaust/Flame */}
      <path d="M42 90L50 100L58 90H42Z" className="opacity-80" />
    </svg>
  </div>
);

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMobileMenuOpen(false);
    setActiveDropdown(null);
    window.scrollTo(0, 0);
  }, [location]);

  const navGroups = [
    { name: 'About', href: '/about' },
    {
      name: 'Media',
      href: '/media',
      links: [
        { name: 'Episodes', href: '/episodes', desc: 'Watch our latest founder conversations.' },
        { name: 'Insights', href: '/insights', desc: 'Deep dives into startup strategy.' },
        { name: 'Events', href: '/events', desc: 'Join our live fireside mixers.' },
      ]
    },
    {
      name: 'Network',
      links: [
        { name: 'Investors', href: '/investors', desc: 'Access our curated founder pipeline.' },
        { name: 'Founders', href: '/founders', desc: 'Strategic media for your startup.' },
        { name: 'Sponsors', href: '/sponsors', desc: 'Partner with the next generation.' },
      ]
    },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 ${isScrolled ? 'bg-white/70 backdrop-blur-2xl py-3 border-b border-slate-200/40 shadow-sm' : 'bg-transparent py-8'}`}
      onMouseLeave={() => setActiveDropdown(null)}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3 group">
          <RocketLogo className="w-8 h-8 md:w-10 md:h-10 text-brand-orange group-hover:scale-110 transition-transform duration-500" />
          <span className="text-xl md:text-2xl font-black tracking-tighter text-slate-900 uppercase font-display group-hover:text-brand-orange transition-colors duration-500">
            FIRESIDE<span className="text-brand-orange">.CC</span>
          </span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-12">
          {navGroups.map((group) => (
            <div 
              key={group.name} 
              className="relative"
              onMouseEnter={() => setActiveDropdown(group.name)}
            >
              {group.links ? (
                <div className="flex items-center gap-2">
                  <Link 
                    to={group.href || '#'}
                    className={`text-[11px] font-black uppercase tracking-[0.2em] transition-all duration-300 relative group/link ${isActive(group.href || '') ? 'text-brand-orange' : 'text-slate-500 hover:text-slate-900'}`}
                  >
                    {group.name}
                    <span className={`absolute -bottom-1 left-0 w-0 h-0.5 bg-brand-orange transition-all duration-300 group-hover/link:w-full ${isActive(group.href || '') ? 'w-full' : ''}`} />
                  </Link>
                  <button 
                    className={`p-1 transition-all duration-300 ${activeDropdown === group.name ? 'text-brand-orange' : 'text-slate-400 hover:text-slate-900'}`}
                  >
                    <motion.div
                      animate={{ rotate: activeDropdown === group.name ? 180 : 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <ArrowRight size={10} className="rotate-90" />
                    </motion.div>
                  </button>
                </div>
              ) : (
                <Link 
                  to={group.href!} 
                  className={`text-[11px] font-black uppercase tracking-[0.2em] transition-all duration-300 relative group/link ${isActive(group.href!) ? 'text-brand-orange' : 'text-slate-500 hover:text-slate-900'}`}
                >
                  {group.name}
                  <span className={`absolute -bottom-1 left-0 w-0 h-0.5 bg-brand-orange transition-all duration-300 group-hover/link:w-full ${isActive(group.href!) ? 'w-full' : ''}`} />
                </Link>
              )}

              {/* Dropdown Menu */}
              <AnimatePresence>
                {group.links && activeDropdown === group.name && (
                  <motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                    className="absolute top-full left-1/2 -translate-x-1/2 pt-6 w-72"
                  >
                    <div className="bg-white rounded-[32px] border border-slate-100 shadow-[0_30px_60px_-15px_rgba(0,0,0,0.1)] p-6 overflow-hidden relative">
                      <div className="absolute top-0 left-0 w-full h-1 bg-brand-orange" />
                      <div className="flex flex-col gap-2">
                        {group.links.map((link) => (
                          <Link
                            key={link.name}
                            to={link.href}
                            className="p-4 rounded-2xl hover:bg-slate-50 transition-all duration-300 group/item"
                          >
                            <p className={`text-xs font-black uppercase tracking-widest mb-1 transition-colors ${isActive(link.href) ? 'text-brand-orange' : 'text-slate-900 group-hover/item:text-brand-orange'}`}>
                              {link.name}
                            </p>
                            <p className="text-[10px] text-slate-400 font-medium leading-relaxed">
                              {link.desc}
                            </p>
                          </Link>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
          <Link to="/apply" className="bg-slate-900 hover:bg-brand-orange text-white px-8 py-3 rounded-full text-[11px] font-black uppercase tracking-[0.2em] transition-all duration-500 shadow-xl hover:shadow-brand-orange/20">
            Apply Now
          </Link>
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden text-slate-900 p-2" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
          {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute top-full left-0 right-0 bg-white border-b border-slate-100 p-8 flex flex-col gap-8 md:hidden shadow-2xl overflow-y-auto max-h-[80vh]"
          >
            {navGroups.map((group) => (
              <div key={group.name} className="flex flex-col gap-4">
                <p className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-400">{group.name}</p>
                {group.links ? (
                  <div className="flex flex-col gap-4 pl-4 border-l border-slate-100">
                    {group.links.map((link) => (
                      <Link 
                        key={link.name} 
                        to={link.href} 
                        className={`text-lg font-black uppercase tracking-tight ${isActive(link.href) ? 'text-brand-orange' : 'text-slate-900'}`}
                      >
                        {link.name}
                      </Link>
                    ))}
                  </div>
                ) : (
                  <Link 
                    to={group.href!} 
                    className={`text-lg font-black uppercase tracking-tight ${isActive(group.href!) ? 'text-brand-orange' : 'text-slate-900'}`}
                  >
                    {group.name}
                  </Link>
                )}
              </div>
            ))}
            <Link to="/apply" className="bg-brand-orange text-white px-6 py-5 rounded-[24px] text-center text-xs font-black uppercase tracking-[0.2em] mt-4 shadow-xl shadow-brand-orange/20">
              Apply to Be Featured
            </Link>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-900 pt-40 pb-16 text-white relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-slate-800 to-transparent" />
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid md:grid-cols-12 gap-20 mb-32">
          <div className="md:col-span-5">
            <Link to="/" className="mb-10 flex items-center gap-4 group">
              <RocketLogo className="w-10 h-10 md:w-12 md:h-12 text-brand-orange group-hover:rotate-12 transition-transform duration-500" />
              <span className="text-2xl md:text-3xl font-black tracking-tighter text-white uppercase font-display group-hover:text-brand-orange transition-colors duration-500">
                FIRESIDE<span className="text-brand-orange">.CC</span>
              </span>
            </Link>
            <p className="text-slate-400 font-medium text-lg max-w-sm leading-relaxed mb-12">
              The premium media engine for the world's most ambitious startup founders and investors.
            </p>
            <div className="flex gap-6">
              <a href="#" className="w-12 h-12 rounded-2xl bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white hover:bg-brand-orange transition-all duration-500"><Linkedin size={20} /></a>
              <a href="#" className="w-12 h-12 rounded-2xl bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white hover:bg-brand-orange transition-all duration-500"><Youtube size={20} /></a>
              <a href="#" className="w-12 h-12 rounded-2xl bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white hover:bg-brand-orange transition-all duration-500"><Twitter size={20} /></a>
            </div>
          </div>
          
          <div className="md:col-span-7 grid grid-cols-2 sm:grid-cols-3 gap-12">
            <div className="flex flex-col gap-6">
              <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-500 mb-2">Platform</h4>
              <Link to="/about" className="text-slate-400 hover:text-brand-orange transition-colors font-bold text-sm uppercase tracking-widest">About</Link>
              <Link to="/episodes" className="text-slate-400 hover:text-brand-orange transition-colors font-bold text-sm uppercase tracking-widest">Episodes</Link>
              <Link to="/insights" className="text-slate-400 hover:text-brand-orange transition-colors font-bold text-sm uppercase tracking-widest">Insights</Link>
              <Link to="/events" className="text-slate-400 hover:text-brand-orange transition-colors font-bold text-sm uppercase tracking-widest">Events</Link>
            </div>
            <div className="flex flex-col gap-6">
              <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-500 mb-2">Network</h4>
              <Link to="/investors" className="text-slate-400 hover:text-brand-orange transition-colors font-bold text-sm uppercase tracking-widest">Investors</Link>
              <Link to="/founders" className="text-slate-400 hover:text-brand-orange transition-colors font-bold text-sm uppercase tracking-widest">For Founders</Link>
              <Link to="/sponsors" className="text-slate-400 hover:text-brand-orange transition-colors font-bold text-sm uppercase tracking-widest">Sponsors</Link>
              <Link to="/apply" className="text-slate-400 hover:text-brand-orange transition-colors font-bold text-sm uppercase tracking-widest">Apply</Link>
            </div>
            <div className="flex flex-col items-start sm:items-end gap-6 col-span-2 sm:col-span-1">
              <button 
                onClick={scrollToTop}
                className="w-14 h-14 rounded-full border border-slate-800 flex items-center justify-center text-slate-500 hover:text-white hover:border-brand-orange hover:bg-brand-orange/10 transition-all duration-500 group"
              >
                <ArrowRight size={24} className="-rotate-90 group-hover:-translate-y-1 transition-transform" />
              </button>
            </div>
          </div>
        </div>
        
        <div className="pt-12 border-t border-slate-800/50 flex flex-col md:flex-row items-center justify-between gap-8">
          <p className="text-slate-500 text-[11px] font-black uppercase tracking-[0.2em]">© 2026 Fireside Media Group. All rights reserved.</p>
          <div className="flex gap-12 text-slate-500 text-[11px] font-black uppercase tracking-[0.2em]">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

// --- Page Sections ---

const Hero = () => (
  <section className="relative min-h-screen flex items-center overflow-hidden pt-20 bg-white">
    <div className="absolute top-0 right-0 w-[45%] h-full bg-slate-50/50 -skew-x-6 translate-x-24 pointer-events-none hidden lg:block" />
    
    <div className="max-w-7xl mx-auto px-6 relative z-10 w-full">
      <div className="grid lg:grid-cols-12 gap-16 items-center">
        <motion.div 
          className="lg:col-span-7"
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
        >
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
            className="inline-flex items-center gap-4 px-5 py-2 rounded-full bg-slate-900 text-[9px] font-black uppercase tracking-[0.4em] text-white mb-12 shadow-2xl shadow-slate-900/20"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-brand-orange animate-pulse" />
            The Media Engine for Builders
          </motion.div>
          <h1 className="text-3xl md:text-5xl font-black tracking-[-0.04em] mb-12 leading-[0.9] text-slate-900 uppercase font-display">
            Engineering <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-orange via-orange-500 to-orange-400">
              Momentum.
            </span>
          </h1>
          <p className="text-xl md:text-2xl text-slate-500 max-w-xl mb-16 leading-relaxed font-medium tracking-tight">
            Fireside spotlights the world's most ambitious founders, bridging the gap between visionary builders and elite capital partners.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center gap-8">
            <Link to="/apply" className="w-full sm:w-auto bg-brand-orange hover:bg-slate-900 text-white px-14 py-6 rounded-full text-[11px] font-black uppercase tracking-[0.2em] transition-all duration-700 shadow-[0_30px_60px_-15px_rgba(242,125,38,0.3)] hover:shadow-slate-900/20 flex items-center justify-center gap-4 group">
              Apply to Feature <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link to="/episodes" className="w-full sm:w-auto bg-white hover:bg-slate-50 border border-slate-200 text-slate-900 px-14 py-6 rounded-full text-[11px] font-black uppercase tracking-[0.2em] transition-all duration-700 flex items-center justify-center gap-4">
              <Play size={18} fill="currentColor" /> Watch Episodes
            </Link>
          </div>

          <div className="mt-24 pt-12 border-t border-slate-100 flex flex-wrap items-center gap-12">
            <div className="flex -space-x-5">
              {[1, 2, 3, 4, 5].map(i => (
                <div key={i} className="w-14 h-14 rounded-full border-[6px] border-white overflow-hidden bg-slate-100 shadow-xl relative group cursor-pointer">
                  <img src={`https://picsum.photos/seed/founder${i+10}/100/100`} alt="Founder" referrerPolicy="no-referrer" className="group-hover:scale-110 transition-transform duration-500" />
                </div>
              ))}
            </div>
            <div className="flex flex-col gap-1.5">
              <p className="text-[9px] font-black uppercase tracking-[0.3em] text-slate-400">Trusted by the elite</p>
              <p className="text-base font-black text-slate-900 uppercase tracking-tighter font-display">500+ Series A-C Founders</p>
            </div>
          </div>
        </motion.div>
 
        <motion.div 
          className="lg:col-span-5 relative"
          initial={{ opacity: 0, scale: 0.9, x: 60 }}
          animate={{ opacity: 1, scale: 1, x: 0 }}
          transition={{ duration: 1.8, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
        >
          <div className="relative z-10 rounded-[80px] overflow-hidden shadow-[0_80px_160px_-40px_rgba(0,0,0,0.3)] aspect-[4/5] border-[16px] border-white group">
            <img 
              src="https://images.unsplash.com/photo-1590602847861-f357a9332bbc?q=80&w=1000&auto=format&fit=crop" 
              alt="Cinematic Podcast Setup" 
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[3000ms] ease-out"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent opacity-60" />
            
            <div className="absolute bottom-16 left-12 right-12">
              <div className="bg-white/10 backdrop-blur-3xl border border-white/20 p-10 rounded-[40px] shadow-2xl">
                <div className="flex items-center gap-6 mb-8">
                  <div className="w-14 h-14 rounded-2xl bg-brand-orange flex items-center justify-center text-white shadow-2xl shadow-brand-orange/40">
                    <Mic2 size={24} />
                  </div>
                  <div>
                    <p className="text-[9px] font-black uppercase tracking-[0.4em] text-white/60 mb-1">Now Streaming</p>
                    <p className="text-lg font-black text-white uppercase font-display tracking-tight">The Narrative Engine</p>
                  </div>
                </div>
                <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: "85%" }}
                    transition={{ duration: 4, delay: 2, ease: "easeOut" }}
                    className="h-full bg-brand-orange shadow-[0_0_20px_rgba(242,125,38,0.5)]"
                  />
                </div>
              </div>
            </div>
          </div>
          
          {/* Decorative Orbs */}
          <div className="absolute -top-32 -right-32 w-96 h-96 bg-brand-orange/20 rounded-full blur-[120px] pointer-events-none animate-pulse" />
          <div className="absolute -bottom-32 -left-32 w-96 h-96 bg-orange-400/15 rounded-full blur-[120px] pointer-events-none" />
        </motion.div>
      </div>
    </div>
  </section>
);

const AboutSection = ({ compact = false }) => {
  const points = [
    { icon: <Mic2 className="text-brand-orange" />, title: "Cinematic Narrative", desc: "We engineer high-production stories that command attention and build authority.", size: "large" },
    { icon: <Users className="text-brand-orange" />, title: "Elite Network", desc: "Direct distribution to the world's most influential capital partners.", size: "small" },
    { icon: <TrendingUp className="text-brand-orange" />, title: "Category Leadership", desc: "Establish your startup as the definitive leader in your space.", size: "small" },
    { icon: <Zap className="text-brand-orange" />, title: "Viral Distribution", desc: "Turn one session into a multi-channel digital presence that scales.", size: "large" },
  ];

  return (
    <section className={`section-padding ${compact ? 'bg-white' : 'bg-slate-50/30'} relative overflow-hidden`}>
      <div className="absolute top-0 right-0 w-1/3 h-full bg-slate-50/50 -skew-x-12 translate-x-32 pointer-events-none" />
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-32 items-start mb-32">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
          >
            <h2 className="text-brand-orange font-bold uppercase tracking-[0.4em] text-[9px] mb-10">The Fireside Advantage</h2>
            <h3 className="text-3xl md:text-5xl font-black mb-12 leading-[0.9] text-slate-900 uppercase font-display tracking-tighter">
              We don’t just <br />interview. <br />
              <span className="text-slate-300">We engineer.</span>
            </h3>
            <p className="text-2xl text-slate-500 mb-16 leading-relaxed font-medium max-w-xl tracking-tight">
              Fireside is a founder-first media engine designed to amplify startup narratives and bridge the gap between builders and capital.
            </p>
            {compact && (
              <Link to="/about" className="inline-flex items-center gap-6 text-slate-900 font-black uppercase tracking-widest text-[10px] hover:gap-8 transition-all group">
                Explore our methodology <ArrowRight size={18} className="text-brand-orange group-hover:translate-x-1 transition-transform" />
              </Link>
            )}
          </motion.div>
          
          <div className="grid sm:grid-cols-2 gap-8">
            {points.map((point, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                whileHover={{ y: -12, scale: 1.02 }}
                className="bg-white p-12 rounded-[50px] border border-slate-100 shadow-sm hover:shadow-2xl transition-all duration-700 group cursor-pointer"
              >
                <div className="mb-12 w-20 h-20 rounded-[32px] bg-slate-50 flex items-center justify-center text-brand-orange group-hover:bg-brand-orange group-hover:text-white transition-all duration-700 shadow-inner">
                  {point.icon}
                </div>
                <h4 className="text-2xl font-black mb-6 text-slate-900 uppercase font-display tracking-tight">{point.title}</h4>
                <p className="text-base text-slate-500 leading-relaxed font-medium tracking-tight">{point.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const HowItWorks = () => {
  const steps = [
    { icon: <CheckCircle2 />, title: "Curation", text: "We select for ambition and vision." },
    { icon: <Mic2 />, title: "Narrative", text: "We craft your strategic story." },
    { icon: <Play />, title: "Production", text: "High-end cinematic recording." },
    { icon: <Share2 />, title: "Distribution", text: "Multi-channel viral reach." },
    { icon: <Target />, title: "Matchmaking", text: "Direct investor introductions." },
  ];

  return (
    <section className="section-padding bg-white relative">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-32">
          <h2 className="text-brand-orange font-bold uppercase tracking-[0.3em] text-[10px] mb-8">The Methodology</h2>
          <h3 className="text-3xl md:text-5xl font-black text-slate-900 uppercase font-display">The Fireside <br />Process</h3>
        </div>
        <div className="grid md:grid-cols-5 gap-12">
          {steps.map((step, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="relative flex flex-col items-center text-center group"
            >
              <div className="w-20 h-20 rounded-[32px] bg-slate-50 border border-slate-100 shadow-sm flex items-center justify-center text-brand-orange group-hover:bg-slate-900 group-hover:text-white transition-all duration-700 mb-10 relative z-10">
                {step.icon}
              </div>
              <h4 className="text-lg font-black text-slate-900 uppercase font-display mb-4 tracking-tight">{step.title}</h4>
              <p className="text-sm text-slate-500 font-medium leading-relaxed">{step.text}</p>
              {idx < steps.length - 1 && (
                <div className="hidden md:block absolute top-10 left-[calc(50%+40px)] w-[calc(100%-80px)] h-px bg-slate-100" />
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const EpisodesSection = ({ limit = 3 }) => {
  const episodes = [
    {
      id: "01",
      title: "The AI Inflection Point",
      guest: "Founder, Nexus AI",
      desc: "Engineering a $200M valuation through strategic narrative and product excellence.",
      label: "Series A Spotlight",
      img: "https://picsum.photos/seed/startup1/1200/800"
    },
    {
      id: "02",
      title: "Fintech Distribution Loops",
      guest: "CEO, PayFlow",
      desc: "How PayFlow captured 40% of the market without a traditional sales team.",
      img: "https://picsum.photos/seed/startup2/1200/800"
    },
    {
      id: "03",
      title: "Building SaaS in Public",
      guest: "Founder, Buildr",
      desc: "The transparency playbook for building a loyal community of 100k+ builders.",
      img: "https://picsum.photos/seed/startup3/1200/800"
    },
    {
      id: "04",
      title: "The Future of Crypto Infrastructure",
      guest: "CTO, ChainLink",
      desc: "Scaling the next generation of decentralized finance through robust oracle networks.",
      img: "https://picsum.photos/seed/startup4/1200/800"
    },
    {
      id: "05",
      title: "Sustainable E-commerce Growth",
      guest: "Founder, EcoCart",
      desc: "How to build a profitable and sustainable brand in the age of fast fashion.",
      img: "https://picsum.photos/seed/startup5/1200/800"
    },
    {
      id: "06",
      title: "HealthTech and AI Diagnostics",
      guest: "CEO, MedVision",
      desc: "Revolutionizing patient care through early detection and AI-driven diagnostics.",
      img: "https://picsum.photos/seed/startup6/1200/800"
    }
  ].slice(0, limit);

  return (
    <section className="section-padding bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row items-end justify-between mb-32 gap-12">
          <div className="max-w-2xl">
            <h2 className="text-brand-orange font-bold uppercase tracking-[0.4em] text-[9px] mb-10">Latest Episodes</h2>
            <h3 className="text-3xl md:text-5xl font-black text-slate-900 uppercase font-display tracking-tighter leading-[0.9]">Masterclass <br />Series</h3>
          </div>
          {limit <= 3 && (
            <Link to="/episodes" className="text-slate-900 font-black uppercase tracking-widest text-[10px] flex items-center gap-6 hover:gap-10 transition-all group">
              View all episodes <ArrowRight size={20} className="text-brand-orange group-hover:translate-x-2 transition-transform" />
            </Link>
          )}
        </div>
        
        <div className="grid md:grid-cols-3 gap-16">
          {episodes.map((ep, idx) => (
            <motion.div 
              key={ep.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: idx * 0.15 }}
              className="group cursor-pointer"
            >
              <div className="relative aspect-[16/11] rounded-[60px] overflow-hidden mb-12 border border-slate-100 shadow-sm group-hover:shadow-2xl transition-all duration-1000">
                <img src={ep.img} alt={ep.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[2000ms] ease-out" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 bg-slate-900/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-700 backdrop-blur-[4px]">
                  <div className="w-24 h-24 rounded-full bg-white flex items-center justify-center text-slate-900 shadow-2xl scale-75 group-hover:scale-100 transition-transform duration-700 ease-out">
                    <Play fill="currentColor" size={32} />
                  </div>
                </div>
                <div className="absolute top-10 left-10 bg-white/90 backdrop-blur-2xl px-6 py-2.5 rounded-full text-[10px] font-black text-slate-900 uppercase tracking-[0.3em] shadow-2xl">
                  EP {ep.id}
                </div>
              </div>
              <div className="px-4">
                {ep.label && <span className="text-[9px] uppercase tracking-[0.4em] text-brand-orange font-black mb-6 block">{ep.label}</span>}
                <h3 className="text-3xl font-black mb-6 text-slate-900 leading-tight group-hover:text-brand-orange transition-colors duration-500 uppercase font-display tracking-tight">{ep.title}</h3>
                <p className="text-[10px] text-slate-400 font-black mb-10 uppercase tracking-widest">{ep.guest}</p>
                <div className="h-px w-12 bg-slate-200 group-hover:w-full group-hover:bg-brand-orange transition-all duration-700" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// --- Pages ---

const PartnersSection = () => {
  const partners = ["Sequoia", "Andreessen", "YC", "First Round", "Accel", "Benchmark"];
  return (
    <section className="py-24 bg-white border-b border-slate-100 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <p className="text-[9px] font-black uppercase tracking-[0.4em] text-slate-400 text-center mb-16">Strategic Partners & Network</p>
        <div className="flex flex-wrap justify-center items-center gap-x-20 gap-y-12 opacity-30 grayscale hover:grayscale-0 transition-all duration-1000 ease-in-out">
          {partners.map(p => (
            <span key={p} className="text-2xl md:text-3xl font-black tracking-[-0.05em] text-slate-900 uppercase font-display">{p}</span>
          ))}
        </div>
      </div>
    </section>
  );
};

const TestimonialsSection = () => {
  const testimonials = [
    {
      quote: "Fireside didn't just tell our story; they engineered the momentum we needed for our Series A. The production quality is unmatched.",
      author: "Sarah Chen",
      role: "CEO, Nexus AI",
      img: "https://picsum.photos/seed/sarah/100/100"
    },
    {
      quote: "The most high-signal media platform in the ecosystem. Every episode is a masterclass in founder vision and tactical execution.",
      author: "Marcus Thorne",
      role: "GP, Thorne Ventures",
      img: "https://picsum.photos/seed/marcus/100/100"
    }
  ];

  return (
    <section className="section-padding bg-slate-50/30 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16">
          {testimonials.map((t, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.2 }}
              className="bg-white p-16 rounded-[60px] border border-slate-100 shadow-sm relative group hover:shadow-2xl transition-all duration-1000"
            >
              <MessageSquare className="absolute top-12 right-16 text-slate-50 group-hover:text-brand-orange/10 transition-colors duration-1000" size={80} />
              <p className="text-2xl md:text-3xl font-medium text-slate-700 mb-12 leading-relaxed italic relative z-10 tracking-tight">
                "{t.quote}"
              </p>
              <div className="flex items-center gap-6">
                <div className="w-16 h-16 rounded-[24px] overflow-hidden border-4 border-slate-50 shadow-xl">
                  <img src={t.img} alt={t.author} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <div>
                  <p className="text-lg font-black text-slate-900 uppercase font-display tracking-tight">{t.author}</p>
                  <p className="text-[10px] font-black text-brand-orange uppercase tracking-[0.3em]">{t.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const NewsletterSection = () => (
  <section className="section-padding bg-white relative overflow-hidden">
    <div className="max-w-7xl mx-auto px-6">
      <div className="bg-slate-900 rounded-[80px] p-16 md:p-32 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-brand-orange/10 -skew-x-12 translate-x-32 pointer-events-none" />
        <div className="max-w-3xl relative z-10">
          <h2 className="text-brand-orange font-bold uppercase tracking-[0.4em] text-[9px] mb-10">Weekly Intelligence</h2>
          <h3 className="text-3xl md:text-5xl font-black text-white mb-12 uppercase font-display leading-[0.9] tracking-tighter">
            The Founder's <br />Playbook.
          </h3>
          <p className="text-xl md:text-2xl text-slate-400 mb-16 font-medium tracking-tight leading-relaxed">
            Join 50,000+ founders and investors receiving our weekly deep-dives on startup strategy and narrative engineering.
          </p>
          <form className="flex flex-col sm:flex-row gap-6">
            <input 
              type="email" 
              placeholder="Enter your email" 
              className="flex-1 bg-white/5 border border-white/10 rounded-full px-10 py-6 text-white outline-none focus:border-brand-orange transition-all font-medium text-lg"
            />
            <button className="bg-brand-orange hover:bg-white hover:text-slate-900 text-white px-14 py-6 rounded-full font-black uppercase tracking-[0.2em] text-[11px] transition-all duration-700 shadow-2xl shadow-brand-orange/20">
              Subscribe
            </button>
          </form>
        </div>
      </div>
    </div>
  </section>
);

const FeaturedInsights = () => {
  const insights = [
    { title: "The Art of Narrative Engineering", category: "Strategy", img: "https://picsum.photos/seed/insight1/1200/800" },
    { title: "Raising Seed in a Bear Market", category: "Fundraising", img: "https://picsum.photos/seed/insight2/1200/800" },
    { title: "Building SaaS Distribution Loops", category: "Growth", img: "https://picsum.photos/seed/insight3/1200/800" },
  ];

  return (
    <section className="section-padding bg-slate-50/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row items-end justify-between mb-32 gap-12">
          <div className="max-w-2xl">
            <h2 className="text-brand-orange font-bold uppercase tracking-[0.4em] text-[9px] mb-10">Insights & Strategy</h2>
            <h3 className="text-3xl md:text-5xl font-black text-slate-900 uppercase font-display tracking-tighter leading-[0.9]">The Founder's <br />Playbook</h3>
          </div>
          <Link to="/insights" className="text-slate-900 font-black uppercase tracking-widest text-[10px] flex items-center gap-6 hover:gap-10 transition-all group">
            Read all insights <ArrowRight size={20} className="text-brand-orange group-hover:translate-x-2 transition-transform" />
          </Link>
        </div>
        <div className="grid md:grid-cols-3 gap-16">
          {insights.map((insight, i) => (
            <motion.div 
              key={i}
              whileHover={{ y: -15 }}
              className="group cursor-pointer"
            >
              <div className="aspect-[16/11] rounded-[60px] overflow-hidden mb-12 border border-slate-100 shadow-sm relative group-hover:shadow-2xl transition-all duration-1000">
                <img src={insight.img} alt={insight.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[2000ms] ease-out" referrerPolicy="no-referrer" />
                <div className="absolute top-10 left-10 bg-white/90 backdrop-blur-2xl px-6 py-2.5 rounded-full text-[9px] font-black text-slate-900 uppercase tracking-[0.3em] shadow-2xl">
                  {insight.category}
                </div>
              </div>
              <h4 className="text-2xl font-black text-slate-900 mb-6 group-hover:text-brand-orange transition-colors uppercase font-display tracking-tight leading-tight">{insight.title}</h4>
              <p className="text-base text-slate-500 font-medium leading-relaxed line-clamp-2 tracking-tight">Tactical advice and deep-dives into the mechanics of startup success.</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Counter = ({ value, duration = 2 }: { value: string; duration?: number }) => {
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const count = useMotionValue(0);

  // Parse the value
  const numericValue = parseFloat(value.replace(/[^0-9.]/g, '')) || 0;
  const prefix = value.match(/^\D+/)?.[0] || '';
  const suffix = value.match(/\D+$/)?.[0] || '';
  const decimals = value.includes('.') ? 1 : 0;

  const rounded = useTransform(count, (latest) => {
    const formatted = latest.toFixed(decimals);
    return `${prefix}${formatted}${suffix}`;
  });

  useEffect(() => {
    if (isInView) {
      animate(count, numericValue, { duration, ease: "easeOut" });
    }
  }, [isInView, count, numericValue, duration]);

  return <motion.span ref={ref}>{rounded}</motion.span>;
};

const StatsSection = () => {
  const stats = [
    { label: "Episodes Released", value: "150+" },
    { label: "Founder Network", value: "500+" },
    { label: "Investor Reach", value: "2.5M+" },
    { label: "Capital Facilitated", value: "$450M+" }
  ];

  return (
    <section className="py-32 bg-slate-900 text-white relative overflow-hidden">
      <div className="absolute inset-0 cinematic-gradient opacity-10 pointer-events-none" />
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-12 text-center">
          {stats.map((stat, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
            >
              <div className="text-4xl md:text-6xl font-black text-brand-orange mb-4 tracking-tighter font-display">
                <Counter value={stat.value} />
              </div>
              <div className="text-[9px] font-black uppercase tracking-[0.3em] text-slate-500">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const FounderSpotlight = () => (
  <section className="section-padding bg-slate-900 relative overflow-hidden">
    <div className="absolute top-0 left-0 w-full h-full cinematic-gradient opacity-30 pointer-events-none" />
    <div className="max-w-7xl mx-auto px-6 relative z-10">
      <div className="grid lg:grid-cols-2 gap-24 items-center">
        <motion.div
          initial={{ opacity: 0, x: -40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
        >
          <h2 className="text-brand-orange font-bold uppercase tracking-[0.4em] text-[9px] mb-10">Founder Spotlight</h2>
          <h3 className="text-3xl md:text-5xl font-black text-white mb-12 uppercase font-display leading-[0.9] tracking-tighter">
            The Visionary <br />Behind <br />
            <span className="text-slate-500 italic font-serif lowercase tracking-normal">Nexus AI.</span>
          </h3>
          <p className="text-xl text-slate-400 mb-16 leading-relaxed font-medium max-w-lg">
            Sarah Chen reveals the tactical playbook used to scale Nexus from a dorm-room prototype to a $200M valuation in 18 months.
          </p>
          <Link to="/episodes/sarah-chen" className="inline-flex items-center gap-6 text-white font-black uppercase tracking-widest text-xs group">
            <div className="w-16 h-16 rounded-full border border-white/20 flex items-center justify-center group-hover:bg-brand-orange group-hover:border-brand-orange transition-all duration-500">
              <Play size={20} fill="currentColor" />
            </div>
            Watch the Masterclass
          </Link>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1.2 }}
          className="relative"
        >
          <div className="aspect-square rounded-[100px] overflow-hidden border-[20px] border-white/5 relative group">
            <img 
              src="https://picsum.photos/seed/sarah-spotlight/1000/1000" 
              alt="Sarah Chen" 
              className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent opacity-60" />
          </div>
          <div className="absolute -bottom-10 -right-10 bg-brand-orange p-10 rounded-[40px] shadow-2xl max-w-xs">
            <p className="text-white font-black text-2xl uppercase font-display leading-tight mb-4">"Fireside is the only platform that truly understands the founder's struggle."</p>
            <p className="text-white/60 text-[10px] font-black uppercase tracking-widest">Sarah Chen, CEO</p>
          </div>
        </motion.div>
      </div>
    </div>
  </section>
);

const ScrollingTicker = () => {
  const items = [
    "Cinematic Narrative",
    "Elite Founder Network",
    "Institutional Capital Reach",
    "Category Leadership",
    "Global Distribution",
    "Founder-First Media",
    "Strategic Narrative",
    "Venture Scale Impact"
  ];

  return (
    <div className="py-10 bg-white border-y border-slate-100 overflow-hidden select-none">
      <div className="flex whitespace-nowrap">
        <motion.div 
          animate={{ x: [0, -1000] }}
          transition={{ 
            duration: 30, 
            repeat: Infinity, 
            ease: "linear" 
          }}
          className="flex items-center gap-16 pr-16"
        >
          {items.concat(items).map((item, i) => (
            <div key={i} className="flex items-center gap-16">
              <span className="text-[11px] font-black uppercase tracking-[0.4em] text-slate-400">
                {item}
              </span>
              <div className="w-px h-4 bg-slate-200" />
            </div>
          ))}
        </motion.div>
        {/* Duplicate for seamless loop */}
        <motion.div 
          animate={{ x: [0, -1000] }}
          transition={{ 
            duration: 30, 
            repeat: Infinity, 
            ease: "linear" 
          }}
          className="flex items-center gap-16 pr-16"
        >
          {items.concat(items).map((item, i) => (
            <div key={i} className="flex items-center gap-16">
              <span className="text-[11px] font-black uppercase tracking-[0.4em] text-slate-400">
                {item}
              </span>
              <div className="w-px h-4 bg-slate-200" />
            </div>
          ))}
        </motion.div>
      </div>
    </div>
  );
};

const HomePage = () => (
  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
    <NoiseOverlay />
    <Hero />
    <ScrollingTicker />
    <PartnersSection />
    <AboutSection compact />
    <StatsSection />
    <HowItWorks />
    <FounderSpotlight />
    <EpisodesSection limit={3} />
    <TestimonialsSection />
    <FeaturedInsights />
    <NewsletterSection />
  </motion.div>
);

const MediaPage = () => (
  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="pt-32">
    <section className="section-padding bg-white">
      <div className="max-w-5xl mx-auto px-6 text-center">
        <h2 className="text-brand-orange font-bold uppercase tracking-[0.4em] text-[9px] mb-10">The Media Hub</h2>
        <h1 className="text-3xl md:text-5xl font-black mb-12 text-slate-900 tracking-tighter uppercase font-display leading-[0.9]">
          Cinematic <br />Storytelling.
        </h1>
        <p className="text-xl md:text-2xl text-slate-500 leading-relaxed font-medium max-w-3xl mx-auto tracking-tight">
          Explore our curated collection of founder masterclasses, strategic insights, and exclusive industry events.
        </p>
      </div>
    </section>

    {/* Media Categories Bento */}
    <section className="section-padding bg-slate-50/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-10">
          {[
            { 
              title: "Episodes", 
              href: "/episodes", 
              desc: "Watch high-production interviews with the world's most ambitious founders.",
              icon: <Play size={32} />,
              img: "https://picsum.photos/seed/media1/800/600"
            },
            { 
              title: "Insights", 
              href: "/insights", 
              desc: "Deep-dives into startup strategy, narrative engineering, and fundraising.",
              icon: <TrendingUp size={32} />,
              img: "https://picsum.photos/seed/media2/800/600"
            },
            { 
              title: "Events", 
              href: "/events", 
              desc: "Join our exclusive live fireside chats and networking mixers in tech hubs.",
              icon: <Globe size={32} />,
              img: "https://picsum.photos/seed/media3/800/600"
            }
          ].map((cat, i) => (
            <Link key={i} to={cat.href} className="group">
              <motion.div 
                whileHover={{ y: -15 }}
                className="bg-white rounded-[60px] overflow-hidden border border-slate-100 shadow-sm hover:shadow-2xl transition-all duration-1000"
              >
                <div className="aspect-[16/10] overflow-hidden relative">
                  <img src={cat.img} alt={cat.title} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-1000" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-slate-900/20 group-hover:bg-transparent transition-colors duration-1000" />
                  <div className="absolute top-10 right-10 w-16 h-16 rounded-2xl bg-white/90 backdrop-blur-xl flex items-center justify-center text-brand-orange shadow-2xl">
                    {cat.icon}
                  </div>
                </div>
                <div className="p-12">
                  <h3 className="text-2xl font-black text-slate-900 uppercase font-display tracking-tight mb-4 group-hover:text-brand-orange transition-colors">{cat.title}</h3>
                  <p className="text-base text-slate-500 font-medium leading-relaxed tracking-tight">{cat.desc}</p>
                </div>
              </motion.div>
            </Link>
          ))}
        </div>
      </div>
    </section>

    <EpisodesSection limit={3} />
    <FeaturedInsights />
    
    <section className="section-padding bg-slate-900 text-white text-center relative overflow-hidden">
      <div className="absolute inset-0 cinematic-gradient opacity-20 pointer-events-none" />
      <div className="max-w-4xl mx-auto px-6 relative z-10">
        <h2 className="text-3xl md:text-5xl font-black mb-10 tracking-tighter uppercase font-display leading-[0.9]">Partner with <br />Fireside Media.</h2>
        <p className="text-xl text-slate-400 mb-16 max-w-2xl mx-auto font-medium tracking-tight">Reach a highly engaged audience of founders, investors, and tech enthusiasts.</p>
        <Link to="/sponsors" className="inline-flex bg-brand-orange text-white px-16 py-7 rounded-full font-black uppercase tracking-[0.2em] text-[11px] hover:bg-white hover:text-slate-900 transition-all duration-700 shadow-2xl shadow-brand-orange/20">
          View Sponsorship Packages
        </Link>
      </div>
    </section>
  </motion.div>
);

const AboutPage = () => (
  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="pt-32">
    {/* Mission Header */}
    <section className="section-padding bg-white">
      <div className="max-w-5xl mx-auto px-6 text-center">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-brand-orange font-bold uppercase tracking-[0.4em] text-[9px] mb-10"
        >
          Our Mission
        </motion.h2>
        <h1 className="text-3xl md:text-5xl font-black mb-12 text-slate-900 tracking-tighter uppercase font-display leading-[0.9]">
          Opening the <br />Closed Doors.
        </h1>
        <p className="text-xl md:text-3xl text-slate-500 leading-relaxed font-medium max-w-3xl mx-auto tracking-tight">
          Fireside was founded on a simple premise: the world's most important companies are built on conversations that often happen behind closed doors. We're opening those doors, spotlighting the visionaries, and engineering the momentum they need to change the world.
        </p>
      </div>
    </section>

    {/* The Genesis Section */}
    <section className="section-padding bg-slate-50/50 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-24 items-center">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
          >
            <h2 className="text-brand-orange font-bold uppercase tracking-[0.4em] text-[9px] mb-10">The Genesis</h2>
            <h3 className="text-3xl md:text-5xl font-black text-slate-900 mb-12 uppercase font-display leading-[0.9] tracking-tighter">
              Born in the <br />Heart of <br />
              <span className="text-slate-300">Innovation.</span>
            </h3>
            <p className="text-xl text-slate-500 mb-10 leading-relaxed font-medium tracking-tight">
              What started as a small recording studio in San Francisco has evolved into a global media engine. We realized that founders didn't just need capital—they needed a narrative that could scale as fast as their code.
            </p>
            <p className="text-xl text-slate-500 mb-12 leading-relaxed font-medium tracking-tight">
              Today, Fireside is the definitive platform for high-signal founder stories, trusted by the world's most influential investors and builders.
            </p>
          </motion.div>
          <div className="relative">
            <div className="aspect-[4/5] rounded-[80px] overflow-hidden border-[16px] border-white shadow-2xl">
              <img src="https://picsum.photos/seed/genesis/800/1000" alt="Genesis" className="w-full h-full object-cover grayscale" referrerPolicy="no-referrer" />
            </div>
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-brand-orange rounded-full blur-[80px] opacity-20" />
          </div>
        </div>
      </div>
    </section>

    <AboutSection />

    {/* Leadership Section */}
    <section className="section-padding bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-32">
          <h2 className="text-brand-orange font-bold uppercase tracking-[0.4em] text-[9px] mb-10">Leadership</h2>
          <h3 className="text-3xl md:text-5xl font-black text-slate-900 uppercase font-display tracking-tighter leading-[0.9]">The Minds <br />Behind Fireside</h3>
        </div>
        <div className="grid md:grid-cols-3 gap-12">
          {[
            { name: "Alex Rivers", role: "Founder & Creative Director", img: "https://picsum.photos/seed/alex/400/500" },
            { name: "Elena Vance", role: "Head of Curation", img: "https://picsum.photos/seed/elena/400/500" },
            { name: "David Kross", role: "Executive Producer", img: "https://picsum.photos/seed/david/400/500" }
          ].map((member, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="group cursor-pointer"
            >
              <div className="aspect-[4/5] rounded-[48px] overflow-hidden mb-10 border border-slate-100 shadow-sm relative">
                <img src={member.img} alt={member.name} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-1000" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent opacity-0 group-hover:opacity-60 transition-opacity duration-700" />
              </div>
              <h4 className="text-2xl font-black text-slate-900 uppercase font-display tracking-tight mb-2 group-hover:text-brand-orange transition-colors">{member.name}</h4>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">{member.role}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>

    {/* Values Section */}
    <section className="section-padding bg-slate-50/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-32">
          <h2 className="text-brand-orange font-bold uppercase tracking-[0.4em] text-[9px] mb-10">Our Core Values</h2>
          <h3 className="text-3xl md:text-5xl font-black text-slate-900 uppercase font-display tracking-tighter leading-[0.9]">Built on <br />Integrity.</h3>
        </div>
        <div className="grid md:grid-cols-3 gap-10">
          {[
            { icon: <ShieldCheck size={32} />, title: "Radical Transparency", desc: "We believe in honest conversations that reveal the true grit behind startup success." },
            { icon: <Award size={32} />, title: "Excellence in Craft", desc: "From sound design to visual storytelling, we never compromise on quality." },
            { icon: <Users size={32} />, title: "Founder-First", desc: "Our platform exists to serve the builder, not the other way around." }
          ].map((value, idx) => (
            <motion.div 
              key={idx}
              whileHover={{ y: -15 }}
              className="p-16 rounded-[60px] bg-white border border-slate-100 shadow-sm hover:shadow-2xl transition-all duration-700 group"
            >
              <div className="w-20 h-20 rounded-[32px] bg-slate-50 flex items-center justify-center text-brand-orange mb-12 shadow-inner group-hover:bg-brand-orange group-hover:text-white transition-all duration-700">{value.icon}</div>
              <h4 className="text-2xl font-black mb-6 text-slate-900 uppercase font-display tracking-tight">{value.title}</h4>
              <p className="text-base text-slate-500 font-medium leading-relaxed tracking-tight">{value.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>

    {/* Global Presence Section */}
    <section className="section-padding bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-24 items-center">
          <div className="order-2 lg:order-1">
            <div className="grid grid-cols-2 gap-6">
              {["San Francisco", "New York", "London", "Singapore"].map((city, i) => (
                <div key={i} className="bg-slate-50 p-10 rounded-[40px] border border-slate-100 text-center group hover:bg-slate-900 transition-all duration-700">
                  <Globe className="mx-auto mb-6 text-brand-orange group-hover:text-white transition-colors" size={32} />
                  <p className="text-lg font-black text-slate-900 uppercase font-display tracking-tight group-hover:text-white transition-colors">{city}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="order-1 lg:order-2">
            <h2 className="text-brand-orange font-bold uppercase tracking-[0.4em] text-[9px] mb-10">Global Presence</h2>
            <h3 className="text-3xl md:text-5xl font-black text-slate-900 uppercase font-display tracking-tighter leading-[0.9]">Operating in <br />Tech Hubs.</h3>
            <p className="text-xl text-slate-500 mb-12 leading-relaxed font-medium tracking-tight">
              We operate out of world-class studios in the world's most vibrant innovation ecosystems, ensuring we're always where the future is being built.
            </p>
          </div>
        </div>
      </div>
    </section>

    {/* Stats Section */}
    <section className="section-padding bg-slate-900 text-white relative overflow-hidden">
      <div className="absolute inset-0 cinematic-gradient opacity-10 pointer-events-none" />
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-12 text-center">
          {[
            { label: "Episodes Released", value: "150+" },
            { label: "Founder Network", value: "500+" },
            { label: "Investor Reach", value: "2.5M+" },
            { label: "Capital Facilitated", value: "$450M+" }
          ].map((stat, idx) => (
            <div key={idx}>
              <div className="text-4xl md:text-7xl font-black text-brand-orange mb-4 tracking-tighter font-display">
                <Counter value={stat.value} />
              </div>
              <div className="text-[9px] font-black uppercase tracking-[0.4em] text-slate-500">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* FAQ Section */}
    <section className="section-padding bg-slate-50/50">
      <div className="max-w-3xl mx-auto px-6">
        <div className="text-center mb-32">
          <h2 className="text-brand-orange font-bold uppercase tracking-[0.4em] text-[9px] mb-10">Common Questions</h2>
          <h3 className="text-3xl md:text-5xl font-black text-slate-900 uppercase font-display tracking-tighter leading-[0.9]">FAQ</h3>
        </div>
        <div className="space-y-8">
          {[
            { q: "How are founders selected?", a: "We look for high-growth startups with unique insights, significant traction, or a compelling vision that challenges the status quo." },
            { q: "Is there a cost to be featured?", a: "We offer both curated editorial spots and sponsored partnership opportunities. Each application is reviewed on its strategic merit." },
            { q: "Where is the content distributed?", a: "Our content reaches millions across LinkedIn, YouTube, TikTok, and our exclusive investor newsletter." },
            { q: "Can investors request introductions?", a: "Yes, we facilitate direct connections between verified investors and the founders featured on our platform." }
          ].map((faq, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="p-12 rounded-[48px] bg-white border border-slate-100 shadow-sm"
            >
              <h4 className="text-2xl font-black mb-6 text-slate-900 uppercase font-display tracking-tight">{faq.q}</h4>
              <p className="text-lg text-slate-500 font-medium leading-relaxed tracking-tight">{faq.a}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  </motion.div>
);

const EpisodesPage = () => (
  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="pt-32">
    <EpisodesSection limit={6} />
  </motion.div>
);

const FoundersPage = () => (
  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="pt-32">
    <section className="section-padding bg-white">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <h1 className="text-3xl md:text-5xl font-black mb-10 text-slate-900 tracking-tighter uppercase font-display leading-[0.9]">For Founders</h1>
        <p className="text-xl md:text-2xl text-slate-500 leading-relaxed font-medium">
          You're building the future. We're here to make sure the right people know about it. Fireside is your strategic media partner for fundraising, hiring, and customer acquisition.
        </p>
      </div>
    </section>
    <HowItWorks />
    <section className="section-padding bg-slate-50/50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-10">
          {[
            { title: 'Share your journey', desc: 'Go beyond the pitch deck and tell the story of why you started, the problems you solved, and the vision you hold.' },
            { title: 'Gain media exposure', desc: 'Reach thousands of founders, investors, and operators in the tech space through our multi-channel distribution.' },
            { title: 'Attract investors', desc: 'Get in front of the right capital partners through our curated network of VCs and high-net-worth individuals.' },
            { title: 'Build authority', desc: 'Establish yourself as a thought leader in your industry through deep-dive technical and strategic discussions.' }
          ].map((item, i) => (
            <div key={i} className="p-12 rounded-[40px] bg-white border border-slate-100 shadow-sm hover:shadow-xl transition-all duration-500">
              <div className="w-14 h-14 rounded-2xl bg-slate-50 flex items-center justify-center text-brand-orange mb-8">
                <CheckCircle2 size={28} />
              </div>
              <h3 className="text-2xl font-extrabold mb-4 text-slate-900">{item.title}</h3>
              <p className="text-slate-500 font-medium leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
        
        <div className="mt-24 text-center">
          <Link to="/apply" className="inline-flex bg-slate-900 text-white px-12 py-5 rounded-full font-bold text-lg hover:bg-slate-800 transition-all shadow-xl">
            Apply to Feature
          </Link>
        </div>
      </div>
    </section>
  </motion.div>
);

const SponsorsPage = () => (
  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="pt-32">
    <section className="section-padding bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="max-w-4xl mb-24">
          <h1 className="text-3xl md:text-5xl font-black mb-10 text-slate-900 tracking-tighter uppercase font-display leading-[0.9]">Partner With Us</h1>
          <p className="text-xl md:text-2xl text-slate-500 leading-relaxed font-medium">
            Align your brand with the next generation of builders. Reach a highly engaged audience of founders, investors, and tech enthusiasts.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-24 mb-24">
          <div className="space-y-12">
            <h3 className="text-2xl md:text-3xl font-extrabold text-slate-900">Why Sponsor?</h3>
            <div className="space-y-8">
              {[
                'Direct access to high-impact decision-makers',
                'Premium brand alignment with startup innovation',
                'Multi-channel exposure (Podcast, Social, Newsletter)',
                'Long-term content value and SEO benefits'
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-6">
                  <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-brand-orange shrink-0">
                    <CheckCircle2 size={20} />
                  </div>
                  <span className="text-lg font-bold text-slate-700">{item}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-slate-50/50 p-12 md:p-16 rounded-[48px] border border-slate-100 shadow-sm">
            <h3 className="text-3xl font-extrabold mb-8 text-slate-900">Sponsorship Packages</h3>
            <p className="text-slate-500 mb-10 font-medium text-lg leading-relaxed">We offer custom, integrated packages tailored to your brand's specific goals, from lead gen to brand authority.</p>
            <button className="w-full bg-slate-900 text-white py-5 rounded-2xl font-bold text-lg hover:bg-slate-800 transition-all shadow-xl">
              Request Media Kit
            </button>
          </div>
        </div>
      </div>
    </section>
  </motion.div>
);

const ApplyPage = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="pt-32 pb-24 bg-slate-50/30">
      <div className="max-w-3xl mx-auto px-6">
        <div className="text-center mb-20">
          <h1 className="text-3xl md:text-5xl font-black mb-8 text-slate-900 tracking-tighter uppercase font-display leading-[0.9]">Pitch Your Story</h1>
          <p className="text-xl text-slate-500 font-medium">Are you building something bold? We curate for ambition, traction, and vision.</p>
        </div>

        <div className="bg-white p-12 md:p-16 rounded-[48px] border border-slate-100 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-brand-orange to-orange-400" />
          
          {submitted ? (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center py-16"
            >
              <div className="w-24 h-24 rounded-full bg-slate-50 flex items-center justify-center text-brand-orange mx-auto mb-10 shadow-inner">
                <CheckCircle2 size={48} />
              </div>
              <h3 className="text-3xl font-extrabold mb-6 text-slate-900">Application Received</h3>
              <p className="text-slate-500 font-medium text-lg mb-12">Our curation team will review your profile and reach out within 48 hours if there's a strategic fit.</p>
              <Link to="/" className="text-slate-900 font-bold underline underline-offset-8 hover:text-brand-orange transition-colors">Back to Home</Link>
            </motion.div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-10">
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-3">
                  <label className="text-[11px] font-bold uppercase tracking-[0.2em] text-slate-400 ml-1">Full Name</label>
                  <input required type="text" className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:border-brand-orange focus:bg-white focus:ring-4 focus:ring-brand-orange/5 outline-none transition-all font-medium text-slate-900" placeholder="Jane Doe" />
                </div>
                <div className="space-y-3">
                  <label className="text-[11px] font-bold uppercase tracking-[0.2em] text-slate-400 ml-1">Startup Name</label>
                  <input required type="text" className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:border-brand-orange focus:bg-white focus:ring-4 focus:ring-brand-orange/5 outline-none transition-all font-medium text-slate-900" placeholder="Acme AI" />
                </div>
              </div>
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-3">
                  <label className="text-[11px] font-bold uppercase tracking-[0.2em] text-slate-400 ml-1">Website URL</label>
                  <input required type="url" className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:border-brand-orange focus:bg-white focus:ring-4 focus:ring-brand-orange/5 outline-none transition-all font-medium text-slate-900" placeholder="https://acme.ai" />
                </div>
                <div className="space-y-3">
                  <label className="text-[11px] font-bold uppercase tracking-[0.2em] text-slate-400 ml-1">Funding Stage</label>
                  <select className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:border-brand-orange focus:bg-white focus:ring-4 focus:ring-brand-orange/5 outline-none transition-all font-medium text-slate-900 appearance-none">
                    <option>Stealth / Pre-seed</option>
                    <option>Seed</option>
                    <option>Series A</option>
                    <option>Series B+</option>
                    <option>Bootstrapped</option>
                  </select>
                </div>
              </div>
              <div className="space-y-3">
                <label className="text-[11px] font-bold uppercase tracking-[0.2em] text-slate-400 ml-1">Why should we feature you?</label>
                <textarea required rows={4} className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:border-brand-orange focus:bg-white focus:ring-4 focus:ring-brand-orange/5 outline-none transition-all resize-none font-medium text-slate-900" placeholder="Tell us about your unique insight or the problem you're solving..."></textarea>
              </div>
              <button type="submit" className="w-full bg-slate-900 text-white py-6 rounded-2xl font-bold text-lg hover:bg-slate-800 transition-all shadow-xl flex items-center justify-center gap-3">
                Submit Application <ArrowRight size={20} />
              </button>
            </form>
          )}
        </div>
      </div>
    </motion.div>
  );
};

const InvestorsPage = () => (
  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="pt-32">
    <section className="section-padding bg-white">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <h1 className="text-3xl md:text-5xl font-black mb-10 text-slate-900 tracking-tighter uppercase font-display leading-[0.9]">For Investors</h1>
        <p className="text-xl md:text-2xl text-slate-500 leading-relaxed font-medium">
          Access a curated pipeline of the world's most ambitious builders. We bridge the gap between visionary founders and elite capital.
        </p>
      </div>
    </section>
    <section className="section-padding bg-slate-50/50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-10">
          {[
            { title: 'Curated Pipeline', desc: 'Get direct access to founders we feature, vetted for traction and vision.' },
            { title: 'Exclusive Insights', desc: 'Deep-dive reports and behind-the-scenes data on emerging sectors.' },
            { title: 'Direct Introductions', desc: 'We facilitate high-signal connections between you and the builders you want to meet.' }
          ].map((item, i) => (
            <div key={i} className="bento-card">
              <div className="w-14 h-14 rounded-2xl bg-slate-50 flex items-center justify-center text-brand-orange mb-8">
                <Target size={28} />
              </div>
              <h3 className="text-2xl font-extrabold mb-4 text-slate-900">{item.title}</h3>
              <p className="text-slate-500 font-medium leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  </motion.div>
);

const EventsPage = () => (
  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="pt-32">
    <section className="section-padding bg-white">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <h1 className="text-3xl md:text-5xl font-black mb-10 text-slate-900 tracking-tighter uppercase font-display leading-[0.9]">Live Events</h1>
        <p className="text-xl md:text-2xl text-slate-500 leading-relaxed font-medium">
          Join us for exclusive fireside chats, networking mixers, and high-impact summits in major tech hubs.
        </p>
      </div>
    </section>
    <section className="section-padding bg-slate-50/50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center py-20">
          <p className="text-slate-400 font-bold uppercase tracking-widest">Upcoming events will be announced soon.</p>
        </div>
      </div>
    </section>
  </motion.div>
);

const InsightsPage = () => {
  const insights = [
    { 
      title: "The Art of Narrative Engineering", 
      category: "Strategy", 
      img: "https://picsum.photos/seed/insight1/1200/800",
      desc: "How to craft a story that resonates with investors and scales your vision."
    },
    { 
      title: "Raising Seed in a Bear Market", 
      category: "Fundraising", 
      img: "https://picsum.photos/seed/insight2/1200/800",
      desc: "Tactical advice for founders navigating the current economic landscape."
    },
    { 
      title: "Building SaaS Distribution Loops", 
      category: "Growth", 
      img: "https://picsum.photos/seed/insight3/1200/800",
      desc: "The mechanics of organic growth and user acquisition for modern SaaS."
    },
    { 
      title: "The Future of Decentralized Infrastructure", 
      category: "Web3", 
      img: "https://picsum.photos/seed/insight4/1200/800",
      desc: "Exploring the next wave of protocol development and what it means for the internet."
    },
    { 
      title: "Hiring for the Zero-to-One Stage", 
      category: "Operations", 
      img: "https://picsum.photos/seed/insight5/1200/800",
      desc: "How to find and attract the right early-stage talent for your startup."
    },
    { 
      title: "Product-Led Growth in Enterprise", 
      category: "Product", 
      img: "https://picsum.photos/seed/insight6/1200/800",
      desc: "Bridging the gap between self-serve products and high-touch enterprise sales."
    }
  ];

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="pt-32">
      <section className="section-padding bg-white">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h1 className="text-3xl md:text-5xl font-black mb-10 text-slate-900 tracking-tighter uppercase font-display leading-[0.9]">Startup Insights</h1>
          <p className="text-xl md:text-2xl text-slate-500 leading-relaxed font-medium">
            Editorial content, industry deep-dives, and tactical advice for the modern builder.
          </p>
        </div>
      </section>
      <section className="section-padding bg-slate-50/50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-12">
            {insights.map((insight, i) => (
              <motion.div 
                key={i} 
                whileHover={{ y: -15 }}
                className="group cursor-pointer"
              >
                <div className="aspect-[16/11] rounded-[60px] overflow-hidden mb-12 border border-slate-100 shadow-sm relative group-hover:shadow-2xl transition-all duration-1000">
                  <img src={insight.img} alt={insight.title} className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-110 transition-all duration-[2000ms] ease-out" referrerPolicy="no-referrer" />
                  <div className="absolute top-10 left-10 bg-white/90 backdrop-blur-2xl px-6 py-2.5 rounded-full text-[9px] font-black text-slate-900 uppercase tracking-[0.3em] shadow-2xl">
                    {insight.category}
                  </div>
                </div>
                <h3 className="text-2xl font-black text-slate-900 mb-6 group-hover:text-brand-orange transition-colors uppercase font-display tracking-tight leading-tight">{insight.title}</h3>
                <p className="text-base text-slate-500 font-medium leading-relaxed tracking-tight">{insight.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </motion.div>
  );
};

const GlobalCTA = () => {
  return (
    <section className="py-32 bg-slate-900 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <svg className="w-full h-full" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="1" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>
      
      {/* Cinematic Glows */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-brand-orange/20 rounded-full blur-[120px] pointer-events-none" />
      
      <div className="max-w-7xl mx-auto px-6 relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-brand-orange font-bold uppercase tracking-[0.4em] text-[10px] mb-10">The Next Chapter</h2>
          <h3 className="text-4xl md:text-7xl font-black text-white mb-12 uppercase font-display leading-[0.85] tracking-tighter">
            Ready to Amplify <br />Your <span className="text-brand-orange">Narrative?</span>
          </h3>
          <p className="text-xl md:text-2xl text-slate-400 mb-16 max-w-2xl mx-auto font-medium leading-relaxed tracking-tight">
            Join the elite network of founders who are engineering their narrative and bridging the gap to institutional capital.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-8 mb-24">
            <Link 
              to="/apply" 
              className="w-full sm:w-auto px-12 py-6 bg-brand-orange text-white font-black uppercase tracking-widest text-xs rounded-full hover:bg-white hover:text-slate-900 transition-all duration-500 shadow-2xl shadow-brand-orange/20"
            >
              Apply for a Session — It's Free
            </Link>
            <Link 
              to="/about" 
              className="w-full sm:w-auto px-12 py-6 border border-white/20 text-white font-black uppercase tracking-widest text-xs rounded-full hover:bg-white/10 transition-all duration-500"
            >
              Our Methodology
            </Link>
          </div>
          
          <div className="flex flex-wrap justify-center items-center gap-x-16 gap-y-8 pt-16 border-t border-white/5">
            {[
              { icon: <ShieldCheck size={20} />, label: "Fully Confidential" },
              { icon: <Zap size={20} />, label: "High-Signal Network" },
              { icon: <Globe size={20} />, label: "Global Distribution" }
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-4 text-white/40 group hover:text-brand-orange transition-colors duration-500">
                <div className="text-brand-orange/50 group-hover:text-brand-orange transition-colors">
                  {item.icon}
                </div>
                <span className="text-[10px] font-black uppercase tracking-widest">{item.label}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

// --- Main App ---

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen selection:bg-brand-orange selection:text-white bg-white relative">
        <div className="noise-overlay" />
        <Navbar />
        <main>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/media" element={<MediaPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/episodes" element={<EpisodesPage />} />
            <Route path="/investors" element={<InvestorsPage />} />
            <Route path="/founders" element={<FoundersPage />} />
            <Route path="/events" element={<EventsPage />} />
            <Route path="/insights" element={<InsightsPage />} />
            <Route path="/sponsors" element={<SponsorsPage />} />
            <Route path="/apply" element={<ApplyPage />} />
          </Routes>
        </main>
        <GlobalCTA />
        <Footer />
      </div>
    </BrowserRouter>
  );
}
